CZ:
Spuštění programu
	Pro spuštění programu stačí pouze rozbalit zazipovaný soubor a spustit program ikonou bakterie.exe
	Dbejte na to, aby cesta, kde je program umístěn, byla bez diakritiky. 
	(V případě komplikací doporučuji umístit složku přímo do adresáře C:\ )
	PDF soubory a soubor bakterie.ini umístěte do stejné složky jako bakterie.exe 
	(Jsou to soubory potřebné pro správné fungování programu.) 
Přihlašovací údaje
	uživatel: host
	heslo: host

EN:
Starting the program
	To start the program, just unzip the zipped file and run the program with the bakterie.exe icon
	Make sure that the path, where the program is located, is without diacritics.
	(In case of complications, I recommend placing the folder directly in the C:\ directory)
	Place the PDF files and the bakterie.ini file in the same folder as bakterie.exe
	(These are the files needed for the program to work properly.)
Program login details
	User: host
	Password: host